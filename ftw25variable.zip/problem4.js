let name = " Name - Ritesh salve";
let school = " School - Masai school india";
let grade = "Grade - A";
let section = "Section - B";
let roll_no = "Roll_No - 07"
console.log(name);
console.log(school);
console.log(grade);
console.log(section);
console.log(roll_no);
let sub_1 = "Hindi = 88";
let sub_2 = "English = 75";
let sub_3 = "Science = 78";
console.log(sub_1);
console.log(sub_2);
console.log(sub_3);