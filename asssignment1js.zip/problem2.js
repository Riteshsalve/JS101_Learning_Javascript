// If a person is allowed to drive in India print "Apply for a license" or "NA".
let person = 18;
if(person>=18){
  console.log("Apply for license");
}
else{
  console.log("NA");
}