// Given stored username and password and input username and password, Print if the user can login or not.
let credentials_username = "Riteshsalve";
let credentials_password = "Ritesh123";
let username = "Riteshsalve";
let password = "Ritesh123";

if(credentials_username == username){
  if(credentials_password == password){
    console.log("i can login");
  }
}
else{
  console.log("i can not login");
}