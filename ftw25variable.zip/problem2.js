let name = "Ritesh salve";
console.log(name);
let father_name = "Ravindra salve";
console.log(father_name);
let mother_name = "kamalbai salve";
console.log(mother_name);
