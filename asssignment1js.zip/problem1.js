let number=45;
console.log(number);
if(number%3==0){
  console.log("given number is multiple of 3");
}
else{
  console.log("number is not multiple of 3");
}